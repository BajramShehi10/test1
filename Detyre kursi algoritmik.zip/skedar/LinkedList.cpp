#include<iostream>
#include<fstream>
#include<string>
#include<stdlib.h>
using namespace std;
typedef struct list{
	string a;
	struct list *pas;
}list;
struct list *k=NULL;


bool gjendet(string fjala){
	if(k==NULL){
		return false;
	}
	struct list *tmp=k;
	while(tmp!=NULL){
		if(tmp->a.compare(fjala)==0){
			return true;
		}
		tmp=tmp->pas;
	}
	return false;
}

void add(string vlera){
    if(gjendet(vlera))
    return;
	struct list *tmp=new list();
	tmp->a=vlera;
	tmp->pas=k;
	k=tmp;
	
}
void afisho(){
	struct list *tmp=k;
	while(tmp!=NULL){
		
		cout<<tmp->a<<" ";
		tmp=tmp->pas;
		
	}
	
		
}
void remove(string vlera){
	if(!gjendet(vlera)){
		cout<<"fjala nk gjendet ne list";
		return;
	}
	if(k==NULL){
		return;
	}
    if(k->a.compare(vlera)==0){
    	k=k->pas;
    	return;
	}
	struct list *tmp=k;
	while(tmp->pas->a.compare(vlera)!=0){
		tmp=tmp->pas;
	}
	tmp->pas=tmp->pas->pas;
	return;
	
}


int main(){
	

	
	fstream in;
	in.open("skedar.txt",ios::in);
	string a;
	while(!in.eof()){
		in>>a;
		add(a);
	}
	afisho();

	
	return 0;
}
