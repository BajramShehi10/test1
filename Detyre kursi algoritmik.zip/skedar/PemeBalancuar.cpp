#include<bits/stdc++.h>
#include<iostream> 
#include<fstream>
#include<Math.h>
using namespace std; 
  
  
typedef struct Node  
{  
    string fjala;
    int key;  
    Node *left;  
    Node *right;  
    int height;  
}Node;  
  
  
  int  celesInt(string fjala){
	
	int  i,s=0;
	for(i=0;i<fjala.length();i++){
		int vl=(int)fjala[i];
	    s+=vl*pow(3,i);
		}
		return s;
}
  
  
int max(int a, int b);  
  

int height(Node *N)  
{  
    if (N == NULL)  
        return 0;  
    return N->height;  
}  

int max(int a, int b)  
{  
    return (a > b)? a : b;  
}  
  
Node* newNode(string fjala)  
{  
    Node* node = new Node(); 
    node->key = celesInt(fjala);  
 	node->fjala=fjala;
    node->left = NULL;  
    node->right = NULL;  
    node->height = 1; 
                      
    return node;  
}  
    
Node *rightRotate(Node *y)  
{  
    Node *x = y->left;  
    Node *T2 = x->right;  
  
      
    x->right = y;  
    y->left = T2;  
  
     
    y->height = max(height(y->left), 
                    height(y->right)) + 1;  
    x->height = max(height(x->left), 
                    height(x->right)) + 1;  
  
      
    return x;  
}  
  
 
Node *leftRotate(Node *x)  
{  
    Node *y = x->right;  
    Node *T2 = y->left;  
  
      
    y->left = x;  
    x->right = T2;  
  
     
    x->height = max(height(x->left),     
                    height(x->right)) + 1;  
    y->height = max(height(y->left),  
                    height(y->right)) + 1;  
  
     
    return y;  
}  
  

int getBalance(Node *N)  
{  
    if (N == NULL)  
        return 0;  
    return height(N->left) - height(N->right);  
}  
  
 
Node* insert(Node* node, string  fjala)  
{  
    
    if (node == NULL)  
        return(newNode(fjala));  
  
    if (celesInt(fjala) < node->key)  
        node->left = insert(node->left, fjala);  
    else if (celesInt(fjala) > node->key)  
        node->right = insert(node->right, fjala);  
    else   
        return node;  
  
    
    node->height = 1 + max(height(node->left),  
                        height(node->right));  
  
    int balance = getBalance(node);  
  
    
    if (balance > 1 && celesInt(fjala) < node->left->key)  
        return rightRotate(node);  
  
     
    if (balance < -1 && celesInt(fjala) > node->right->key)  
        return leftRotate(node);  
  
   
    if (balance > 1 && celesInt(fjala) > node->left->key)  
    {  
        node->left = leftRotate(node->left);  
        return rightRotate(node);  
    }  
  
   
    if (balance < -1 && celesInt(fjala) < node->right->key)  
    {  
        node->right = rightRotate(node->right);  
        return leftRotate(node);  
    }  
  
    
    return node;  
}  
  

void preOrder(Node *root)  
{  
    if(root != NULL)  
    {  
        cout << root->fjala << " ";  
        preOrder(root->left);  
        preOrder(root->right);  
    }  
}  
  

int main()  
{  
    Node *root = NULL;  
       fstream in;
	in.open("skedar.txt",ios::in);
	string a;
	while(!in.eof()){
		in>>a;
		root=insert(root,a);
	} 
    preOrder(root);  
      
    return 0;  
}  
  
