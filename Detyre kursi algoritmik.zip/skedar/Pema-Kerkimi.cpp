#include<iostream>
#include<Math.h>
#include<fstream>
using namespace std;
typedef struct peme{
	double celes;
	string fjala;
	struct peme*p, *m, *d;
}peme;
peme*T;

/*-----------------------Celes Int--------------------------*/
double celesInt(string fjala){
	int i;
	double s=0;
	for(i=0; i<fjala.length(); i++){
		int vl=(int)fjala[i];
		s+=vl*pow(3,i);
	}
	return s;
	}
	
/*----------------------Gjendet----------------------------*/
bool gjendet(peme*k, string fjala){
	double a=celesInt(fjala);
	peme*tmp=k;
	while(tmp!=NULL){
		if(tmp->celes==a)
		return true;
		else if(tmp->celes>a){
			tmp=tmp->m;
		}
		else{
			tmp=tmp->d;
		}
	}
	return false;
}

/*-----------------------Shto ne kulm-----------------------*/
void add(string fjala){
	if(gjendet(T, fjala))
	return;
	peme*y=NULL;
	peme*tmp=T;
	peme*kulm=new peme;
	kulm->celes=celesInt(fjala);
	kulm->fjala=fjala;
	kulm->m=NULL;
	kulm->d=NULL;
	kulm->p=NULL;
	
while(tmp!=NULL){
	y=tmp;
	if(kulm->celes<tmp->celes){
		tmp=tmp->m;
	}
	else{
		tmp=tmp->d;
	}
}
kulm->p=y;
if(y==NULL){
	T=kulm;
}
else if(kulm->celes<y->celes){
	y->m=kulm;
}
else{
	y->d=kulm;
}
}

/*-------------------------Afishimi----------------------------*/
void afisho(peme*k){
	if(k==NULL)
	return;
	
	afisho(k->m);
	cout<<k->fjala<<" ";
	afisho(k->d);
}

/*---------------------------Minimumi------------------------------*/
peme*Minimum(peme*k){
	peme*tmp=k;
	while(tmp->m!=NULL){
		tmp=tmp->m;
	}
	return tmp;
}

/*--------------------------Zevendesimi---------------------------*/
void Zevendeso(peme*u, peme*v){
	if(u->p==NULL)
	T=v;
	else
	if(u==u->p->m)
	u->p->m=v;
	else
	u->p->d=v;
	if(v!=NULL)
	v->p=u->p;
}

/*------------------------------Gjej Kulm------------------------------*/
peme*gjejKulm(string fjala){
	double a=celesInt(fjala);
	peme*tmp=T;
	while(tmp!=NULL){
		if(tmp->celes==a)
		return tmp;
		else if(tmp->celes>a){
			tmp=tmp->m;
		}
		else{
			tmp=tmp->d;
		}
	}
	return NULL;
}

/*--------------------------------Heqje------------------------------*/
void fshi(string fjala)
{
	if(!gjendet(T, fjala))
	return;
peme*z=gjejKulm(fjala);
peme*y;
if(z->m==NULL)
Zevendeso(z, z->d);
else
if(z->d==NULL)
Zevendeso(z, z->m);
else
{
	y=Minimum(z->d);
	if(y->p!=z){
		Zevendeso(y, y->d);
		y->d=z->d;
		y->d->p=y;
		}
		Zevendeso(z, y);
		y->m=z->m;
		y->m->p=y;
	}
}

int main(){
	fstream in;
	in.open("skedar.txt", ios::in);
	string a;
	while(!in.eof()){
		in>>a;
		add(a);
	}
	afisho(T);
	cout<<endl;
	
	string b="great";
	fshi(b);
	afisho(T);
}
